import { Atmosphere } from '../src/sim/atmosphere';
import { PRESETS, runValidation, parcelAscent } from '../src/sim/thermo';
import { Terrain } from '../src/sim/terrain';
const checks = runValidation();
for (const c of checks) console.log(c.ok ? 'PASS' : 'FAIL', c.name, c.value, c.expect);
const N = Number(process.argv[3] || 64), NZ = Number(process.argv[4] || 36);
const pid = process.argv[2] || 'pulse';
const hours = Number(process.argv[5] || 4);
const t0 = Date.now();
const terr = new Terrain(256);
console.log('terrain', Date.now() - t0, 'ms');
const a = new Atmosphere(N, NZ, PRESETS.find((p) => p.id === pid)!, terr);
// initial CAPE
const T = new Float64Array(NZ);
for (let k = 0; k < NZ; k++) T[k] = a.th[k * N * N] * a.prof.pi[k];
const pa = parcelAscent(a.prof.z, a.prof.p, T, Array.from({length:NZ},(_,k)=>a.qv[k*N*N]), 'SB');
console.log('init column SB', pa);
let tw = Date.now(); let steps = 0; let nextPrint = 0;
const tEnd = a.time + hours * 3600;
let flashes = 0;
while (a.time < tEnd) {
  a.step(); steps++;
  for (const e of a.flashEvents) { flashes++; if (flashes<=40) console.log(`  FLASH t=${(a.time/3600).toFixed(3)}h ${e.type} segs=${e.segs.length/10} Q=${e.chargeC.toFixed(1)}C ratio=${e.ratio.toFixed(2)} init z=${e.init[1].toFixed(0)} strokes=${e.strokes.length} strike=${e.strike?e.strike.map(v=>v.toFixed(0)).join(','):'-'}`); } a.flashEvents.length = 0;
  if (a.time >= nextPrint) {
    nextPrint = a.time + 1800;
    const s = a.stats;
    console.log(`t=${(a.time / 3600).toFixed(2)}h dt=${a.dt.toFixed(1)} step=${((Date.now() - tw) / steps).toFixed(0)}ms maxW=${s.maxW.toFixed(1)}/${s.minW.toFixed(1)} qc=${(s.maxQc * 1e3).toFixed(2)} qi=${(s.maxQi*1e3).toFixed(2)} qr=${(s.maxQr * 1e3).toFixed(2)} qg=${(s.maxQg*1e3).toFixed(2)} rain=${s.maxRain.toFixed(1)} cf=${s.cloudFrac.toFixed(2)} cp=${s.coldPool.toFixed(3)}/${s.coldPoolMin.toFixed(1)} Ts=${s.meanTs.toFixed(1)} div=${s.maxDiv.toExponential(1)} cfl=${s.cfl.toFixed(2)} wres=${s.waterRes.toExponential(1)} eres=${s.energyRes.toExponential(1)} E=${(s.maxE/1e3).toFixed(0)}kV/m r=${s.maxEratio.toFixed(2)} fl=${flashes} UH=${s.maxUH.toFixed(0)} KE=${s.KE.toExponential(1)} chMax=${a.chargeMax.toExponential(1)} Q+=${s.chargePos.toExponential(1)} Q-=${s.chargeNeg.toExponential(1)}`);
    if (!isFinite(s.KE)) { console.log('BLOWUP'); break; }
  }
}
console.log('total', Date.now() - tw, 'ms steps', steps);
